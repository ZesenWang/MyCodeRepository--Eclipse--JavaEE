package com.tutorialspoint;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestSpring {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			//获取applicationContext.xml文件中的bean
			ApplicationContext context=
					new ClassPathXmlApplicationContext("applicationContext.xml");
			LoginAction logAction=(LoginAction)context.getBean("loginAction");
			String result=logAction.login();
			
			System.out.println(result);
		}catch(Exception e){
			System.err.println(e);
		}	
	}

}
