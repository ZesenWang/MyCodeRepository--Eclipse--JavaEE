package com.tutorialspoint;
import java.util.*;


public class UsrDAO {
	public String checkUsr(String name){
		if(name.equals("ttt")){
			return "success";
		}else{
			return "error";
		}	
	}
}
