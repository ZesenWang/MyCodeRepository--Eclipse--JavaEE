package com.tutorialspoint;


public class LoginAction{
	private String userName;
	private String password;
	private UsrDAO dao;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UsrDAO getDao() {
		return dao;
	}
	public void setDao(UsrDAO dao) {
		this.dao = dao;
	}
	public String login(){
		//UsrDAO dao=new UsrDAO();
		//用户应用程序中的测试，假设页面中传过来的用户名为“ttt"
		this.userName="ttt";
		
		//这里的dao由spring的配置文件注入得到
		String str=dao.checkUsr(this.getUserName());	
		return str;
	}
}

